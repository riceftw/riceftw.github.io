# riceftw.github.io

To deploy the website from the home page first open the "index.html" file. From the home page there are several options available. To find information on how to contact us simply click the "Contact Us" at the top left. In addition to the contact us feature, finding information on your account and your orders are also located at the top left. The search function is not implemented but the search box is placed there as a placeholder. To Login and see your current shopping cart simply select the corresponding button at the top right. 

To begin designing your case, the main function of our website, first decide what type of iPhone case you wish to buy for iPhone. There is a selection of three choices: leather case, wood case, and shock proof case. Once you have decided on a case, select your type of iPhone from the drop down menu below each of the materials. Once you have done that click the customize button to begin customizing your case.

On the customization page (Options.html), you can select the background you want your case to be. Each of the three options Glossy, Leather, and Wood have their own colors and types. To select your background simply hover over the type you want, and a drop down menu will appear. From there choose the option you want by clicking the checkbox. Once you have finished click the "Add to Cart" button at the bottom right. If you want to change your phone material or type you can click the back button at the bottom of the page.

Our current Login page and Shopping Cart are both placeholders for future implementations where we can add payment options, login functionality, and modifying your current order.

If at anytime you wish to return to the homepage, simply click the logo at the top of every page in order to go back to the homepage.

